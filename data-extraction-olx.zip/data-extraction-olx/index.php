<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
@set_time_limit(0);
@ini_set("memory_limit", -1); # 1GB
@ini_set("max_execution_time", 0);
require_once 'simplehtmldom'. DIRECTORY_SEPARATOR .'simple_html_dom.php';

// VARIABLES
$filename = "Data_Extraction_" . date('YmdHis') . '.csv';
$target_url = 'http://mt.olx.com.br/imoveis/terrenos/fazendas';
$html_elements = array(
    'list' => 'ul[id=main-ad-list] li a',
    'pagination' => 'div[class=module_pagination] ul li a',
    'date' => 'div[class=OLXad-date] p',
    'price' => 'div[class=OLXad-price] span',
    'description' => 'div[class=OLXad-description mb30px] p',
    'details' => 'div[class=OLXad-details mb30px] ul[class=list square-gray] li',
    'details_span' => 'div[class=OLXad-details mb30px] ul[class=list square-gray] li p span',
    'size_or_type' => 'div[class=OLXad-details mb30px] ul[class=list square-gray] li p strong',
    'location_map' => 'div[class=OLXad-location-map mb20px] ul[class=list square-gray] li',
    'location_map_span' => 'div[class=OLXad-location-map mb20px] ul[class=list square-gray] li p span',
    'municipality_or_cep_map' => 'div[class=OLXad-location-map mb20px] ul[class=list square-gray] li p strong',
    'location' => 'div[class=OLXad-location mb20px] ul[class=list square-gray] li',
    'location_span' => 'div[class=OLXad-location mb20px] ul[class=list square-gray] li p span',
    'municipality_or_cep' => 'div[class=OLXad-location mb20px] ul[class=list square-gray] li p strong'
);
$first_page = 1;
$last_page = 1;
$pagination_url = '';
$key = 0;
$month = date('m');
$year = date('Y');
date_default_timezone_set("America/New_York");


$data = deo();
createCSV($data);
exit;

function deo() {
    global $target_url, $html_elements, $first_page, $last_page, $pagination_url, $key;
    $_olx = array();
    $list = array();
    $html = file_get_html($target_url);
    if (!empty($html->find($html_elements['list']))) {
        $list = $html->find($html_elements['list']);
    }
    if (!empty($html->find($html_elements['pagination']))) {
        $pagination = $html->find($html_elements['pagination']);
        $pagination = array_slice($pagination, -1, 1, true);
        foreach ($pagination as $element) {
            $split = explode('=', $element->href);
            $last_page = $split[1];
            $pagination_url = $split[0];
        }
    }
    while ($first_page <= $last_page) {
        if ($first_page != 1) {
            $list = array();
            $html = file_get_html($pagination_url . '=' . $first_page);
            if (!empty($html) && !empty($html->find($html_elements['list']))) {
                $list = $html->find($html_elements['list']);
            }
        }
        $today = new DateTime();
        if (!empty($list)) {
            foreach ($list as $element) {
                $_detail_existed = false;
                $detail = file_get_html($element->href);
                if (!empty($detail)) {
                    if (!empty($detail->find($html_elements['date'], 0))) {
                        $date = $detail->find($html_elements['date'], 0)->plaintext;
                        $date = explode(": ", $date);
                        $_olx[$key]['date'] = convertDate(trim(str_replace('.', '', $date[1])));
                        $_detail_existed = true;
                    }
                    if (!empty($detail->find($html_elements['price'], 0))) {
                        $_olx[$key]['price'] = trim($detail->find($html_elements['price'], 0)->plaintext);
                        $_detail_existed = true;
                    }
                    if (!empty($detail->find($html_elements['description'], 0))) {
                        $_olx[$key]['description'] = trim($detail->find($html_elements['description'], 0)->innertext);
                        $_detail_existed = true;
                    }

                    if (!empty($detail->find($html_elements['details']))) {
                        $total_detail = $detail->find($html_elements['details']);
                        for ($i = 0; $i < count($total_detail); $i++) {
                            $span = $detail->find($html_elements['details_span'], $i)->plaintext;
                            if (strtolower(trim($span)) == 'tipo:') {
                                $_olx[$key]['type'] = trim($detail->find($html_elements['size_or_type'], $i)->plaintext);
                            } else if (strtolower(trim($span)) == 'tamanho:') {
                                $_olx[$key]['size'] = trim($detail->find($html_elements['size_or_type'], $i)->plaintext);
                            }
                        }
                        $_detail_existed = true;
                    }

                    if (!empty($detail->find($html_elements['location_map']))) {
                        $total_loc = $detail->find($html_elements['location_map']);
                        for ($i = 0; $i < count($total_loc); $i++) {
                            $span = $detail->find($html_elements['location_map_span'], $i)->plaintext;
                            if (strtolower(trim($span)) == 'munic�pio:') {
                                $_olx[$key]['municipality'] = trim($detail->find($html_elements['municipality_or_cep_map'], $i)->plaintext);
                            } else if (strtolower(trim($span)) == 'cep do im�vel:') {
                                $_olx[$key]['cep'] = trim($detail->find($html_elements['municipality_or_cep_map'], $i)->plaintext);
                            }
                        }
                        $_detail_existed = true;
                    } else if (!empty($detail->find($html_elements['location']))) {
                        $total_loc = $detail->find($html_elements['location']);
                        for ($i = 0; $i < count($total_loc); $i++) {
                            $span = $detail->find($html_elements['location_span'], $i)->plaintext;
                            if (strtolower(trim($span)) == 'munic�pio:') {
                                $_olx[$key]['municipality'] = trim($detail->find($html_elements['municipality_or_cep'], $i)->plaintext);
                            } else if (strtolower(trim($span)) == 'cep do im�vel:') {
                                $_olx[$key]['cep'] = trim($detail->find($html_elements['municipality_or_cep'], $i)->plaintext);
                            }
                        }
                        $_detail_existed = true;
                    }
                    if ($_detail_existed) {
                        $_olx[$key]['name'] = $element->name;
                        $_olx[$key]['id'] = $element->id;
                        $_olx[$key]['url'] = $element->href;
                        $_olx[$key]['title'] = $element->title;
                        $_olx[$key]['cap_date'] = $today->format('Y-m-d');
                        $key++;
                    }
                }
            }
        }
        $first_page++;
    }
    return $_olx;
}

function convertDate($date) {
    global $year, $month;
    $converted = false;
    $default = array(
        'janeiro' => 'January',
        'fevereiro' => 'February',
        'marcha' => 'March',
        'abril' => 'April',
        'pode' => 'May',
        'junho' => 'June',
        'julho' => 'July',
        'agosto' => 'August',
        'setembro' => 'September',
        'outubro' => 'October',
        'novembro' => 'November',
        'dezembro' => 'December',
        'maio' => 'May',
        'mar�o' => 'March'
    );
    $_date = utf8_encode(strtolower($date));
    
    foreach ($default as $key => $value) {
        if (strpos($_date, $key) !== false) {
            $_date = str_replace($key, $value, $_date);
            $_date = str_replace(['às','�s'], '', $_date);
            $converted = true;
        }
    }
    if ($converted) {
        $_new = explode(" ", $_date);
        $time = ' T 00:00:00';
        if (strpos(end($_new), ':') !== false) {
            $time_pos = strpos($_date, end($_new));
            $new_date = new DateTime(trim(substr($_date, 0, $time_pos)));
            $time = end($_new);
            $_time = explode(":", end($_new));
            if (count($_time) == 1) {
                $time = ' T ' . end($_new) . ':00:00';
            } else if (count($_time) == 2) {
                $time = ' T ' . end($_new) . ':00';
            }
        } else {
            $new_date = new DateTime($_date);
        }
        if ($new_date->format('m') > $month) {
            $year = $year - 1;
        }
        $month = $new_date->format('m');
        return $year . '-' . $new_date->format('m-d') . $time;
    } else {
        return $date;
    }
}

function createCSV($data) {
    global $filename;
    $fp = fopen($filename, 'w');
    $header = "Title,Name,Id,Url,Date,Price,Description,Type,Size,Municipality,CEP,Date_Captured\n";
    fputs($fp, $header);
    $line = '';
    foreach ($data as $key => $value) {
        $line .= clean_string($value['title']) . ',';
        $line .= clean_string($value['name']) . ',';
        $line .= clean_string($value['id']) . ',';
        $line .= clean_string($value['url']) . ',';

        if (array_key_exists('date', $value)) {
            $line .= clean_string($value['date']) . ',';
        } else {
            $line .= "" . ',';
        }
        if (array_key_exists('price', $value)) {
            $line .= clean_string($value['price']) . ',';
        } else {
            $line .= "" . ',';
        }
        if (array_key_exists('description', $value)) {
            $line .= clean_string($value['description']) . ',';
        } else {
            $line .= "" . ',';
        }
        if (array_key_exists('type', $value)) {
            $line .= clean_string($value['type']) . ',';
        } else {
            $line .= "" . ',';
        }
        if (array_key_exists('size', $value)) {
            $line .= clean_string($value['size']) . ',';
        } else {
            $line .= "" . ',';
        }
        if (array_key_exists('municipality', $value)) {
            $line .= clean_string($value['municipality']) . ',';
        } else {
            $line .= "" . ',';
        }
        if (array_key_exists('cep', $value)) {
            $line .= clean_string($value['cep']) . ',';
        } else {
            $line .= "" . ',';
        }
        if (array_key_exists('cap_date', $value)) {
            $line .= clean_string($value['cap_date']) . ',';
        } else {
            $line .= "" . ',';
        }
        $line .= "\n";
    }
    fputs($fp, $line);
    fclose($fp);
    echo PHP_EOL . PHP_EOL . '   ***************************** Data Extracted **************************   ' . PHP_EOL . PHP_EOL;
    echo '    ' . dirname(__FILE__) . DIRECTORY_SEPARATOR . $filename . PHP_EOL . PHP_EOL;
    echo '   ***********************************************************************   ';
    exit;
}

function clean_string($string) {
    return '"' . str_replace('"', '"', str_replace("\r", "", str_replace("\n", "", str_replace("\"", "\"\"", $string)))) . '"';
}

function cURL($target_url) {
    $ch1 = curl_init();
    curl_setopt($ch1, CURLOPT_URL, $target_url);
    curl_setopt($ch1, CURLOPT_HEADER, 0);
    curl_setopt($ch1, CURLOPT_VERBOSE, 1);
    curl_setopt($ch1, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Media Center PC 4.0)');
    curl_setopt($ch1, CURLOPT_REFERER, 'http://www.google.com');  //just a fake referer
    curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch1, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch1, CURLOPT_POST, 0);
    curl_setopt($ch1, CURLOPT_FOLLOWLOCATION, 20);
    $htmlContent = curl_exec($ch1);
    curl_close($ch1);
    return $htmlContent;
}

?>